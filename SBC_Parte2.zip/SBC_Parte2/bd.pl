﻿:-[base_conhecimento].


%   simple state representation: S, where S is a city
initial(restaurante). % local inicial
goal(client5). % destino




%caminho (pontoA, pontoB)
caminho(cliente1, cliente2)
caminho(cliente2, cliente1)
caminho(restaurante, cliente1)
caminho(cliente1, restaurante)
caminho(restaurante, cliente4)
caminho(cliente4, restaurante)
caminho(cliente1, cliente5)
caminho(cliente5, cliente1)
caminho(cliente4, cliente1)
caminho(cliente1, cliente4)
caminho(cliente4, cliente2)
caminho(cliente2, cliente4)
caminho(cliente4, cliente3)
caminho(cliente3, cliente4)
caminho(cliente2, cliente5)
caminho(cliente5, cliente2)
caminho(cliente2, cliente3)
caminho(cliente3, cliente2)
caminho(cliente5, cliente3)
caminho(cliente3, cliente5)




%tempo(pontoA, pontoB, temp)
tempo(cliente1, cliente2, 5)
tempo(cliente2, cliente1, 5)
tempo(restaurante, cliente1, 5)
tempo(cliente1, restaurante, 5)
tempo(restaurante, cliente4, 7)
tempo(cliente4, restaurante, 7)
tempo(cliente1, cliente5, 5)
tempo(cliente5, cliente1, 5)
caminho(cliente4, cliente1, 5)
caminho(cliente1, cliente4, 5)
caminho(cliente4, cliente2, 2)
caminho(cliente2, cliente4, 2)
caminho(cliente4, cliente3, 4)
caminho(cliente3, cliente4, 4)
caminho(cliente2, cliente5, 2)
caminho(cliente5, cliente2, 2)
caminho(cliente2, cliente3, 3)
caminho(cliente3, cliente2, 3)
caminho(cliente5, cliente3, 5)
caminho(cliente3, cliente5, 5)




%lucro(pontoA, pontoB, lucr)
lucro(cliente1, cliente2, 6)
lucro(cliente2, cliente1, 5)
lucro(restaurante, cliente1, 5)
lucro(cliente1, restaurante, )
lucro(restaurante, cliente4)
lucro(cliente4, restaurante)
lucro(cliente1, cliente5, )
lucro(cliente5, cliente1, 5)
lucro(cliente4, cliente1)
lucro(cliente1, cliente4)
lucro(cliente4, cliente2, 6)
lucro(cliente2, cliente4, )
lucro(cliente4, cliente3, 7)
lucro(cliente3, cliente4, )
lucro(cliente2, cliente5, )
lucro(cliente5, cliente2, 6)
lucro(cliente2, cliente3, 7)
lucro(cliente3, cliente2, 6)
lucro(cliente5, cliente3, 7)
lucro(cliente3, cliente5, )